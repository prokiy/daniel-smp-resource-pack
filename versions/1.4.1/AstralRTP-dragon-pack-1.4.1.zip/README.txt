AstralRTP 1.4.1. Exact Minecraft EnderDragonModel geometry and setupAnim frames, using the game's own dragon and eye textures. Java 1.21.11 through 26.2.
