Daniel SMP / AstralRTP 1.4.0. Original full dragon model and textures. Requires Minecraft Java 1.21.11.
